"""Composition root for ForgeAI's desktop interface."""

import base64
import json
import logging
import uuid
from pathlib import Path

from PySide6.QtCore import Qt
from PySide6.QtGui import QAction
from PySide6.QtWidgets import (
    QFileDialog, QLabel, QMainWindow, QMessageBox, QSplitter, QToolBar,
    QVBoxLayout, QWidget,
)

from forgeai.ai.agent_contracts import AgentTask
from forgeai.ai.agent_orchestrator import AgentOrchestrator
from forgeai.ai.agent_state import AgentRun, AgentState
from forgeai.ai.agent_ui_worker import AgentRecoveryWorker, AgentVerificationWorker, AgentWorkflowWorker
from forgeai.ai.change_actions import extract_change_previews
from forgeai.ai.ollama_client import OllamaClient
from forgeai.ai.prompts import SYSTEM_PROMPT, PROMPT_CREATION_INSTRUCTIONS
from forgeai.ai.request_routing import (
    is_project_change_request, is_creative_prompt_request, is_standalone_prompt_request,
)
from forgeai.config import Config
from forgeai.core.ai_context import AIContextProvider
from forgeai.core.evidence_validator import EvidenceValidator
from forgeai.core.project_evidence import ProjectEvidence
from forgeai.core.reality_collector import RealityCollector
from forgeai.core.agent_reality import AgentReality
from forgeai.core.file_indexer import FileIndexer
from forgeai.core.history import History
from forgeai.core.models import ProjectMode
from forgeai.core.task_manager import TaskManager
from forgeai.core.workspace_database import WorkspaceDatabase
from forgeai.core.workspace_manager import WorkspaceManager
from forgeai.core.workspace_tools import ChangePreview, WorkspaceTools
from forgeai.ui.chat_view import ChatView
from forgeai.ui.file_viewer import FileViewer
from forgeai.ui.input_bar import InputBar
from forgeai.ui.project_panel import ProjectPanel
from forgeai.ui.settings_dialog import SettingsDialog
from forgeai.ui.sidebar import Sidebar
from forgeai.ui.tasks_dialog import TasksDialog
from forgeai.ui.terminal_panel import TerminalPanel


class MainWindow(QMainWindow):
    """Coordinates UI components while services retain workspace state."""

    AI_CONTROL_FILES = {
        "forgeai/ai/change_actions.py",
        "forgeai/core/filesystem.py",
        "forgeai/core/workspace_tools.py",
        "forgeai/ui/change_proposal.py",
        "forgeai/ui/chat_view.py",
        "forgeai/ui/main_window.py",
    }

    def __init__(self, database: WorkspaceDatabase):
        super().__init__()
        self.database = database
        self.logger = logging.getLogger("forgeai.ui")
        self.history = History(database)
        self.workspace = WorkspaceManager(database, FileIndexer(database))
        self.ai_context = AIContextProvider(
            database,
            self.workspace.filesystem,
            accessible_files_provider=self.workspace.ai_accessible_files,
        )
        self.evidence_validator = EvidenceValidator()
        self.tasks = TaskManager(database)
        self.ollama = OllamaClient()
        self.worker = None
        self.chat_id: int | None = None
        self._pending_user_request = ""
        self._agent_worker: AgentWorkflowWorker | None = None
        self._agent_verification_worker: AgentVerificationWorker | None = None
        self._agent_recovery_worker: AgentRecoveryWorker | None = None
        self._agent_orchestrator: AgentOrchestrator | None = None
        self._agent_task: AgentTask | None = None
        self._agent_reality: AgentReality | None = None
        self._agent_plan = None
        self._agent_project_context = ""
        self._agent_num_ctx: int | None = None
        self.agent_review_enabled = self._setting("agent_review_enabled", "true").casefold() not in {"0", "false", "off", "no"}
        self._stream_is_action = False
        self._pending_change_previews = None
        self.ollama_url = Config.LOCAL_OLLAMA_URL
        self._save_setting("ollama_url", self.ollama_url)
        self.model = self._setting("model", Config.DEFAULT_MODEL)
        self.setWindowTitle(Config.APP_NAME)
        self.setMinimumSize(1000, 650)
        self.resize(1600, 900)
        self._build_ui()
        self._build_menus()
        self._apply_theme()
        self._restore_window()
        self._restore_chat()

    def _build_ui(self) -> None:
        toolbar = QToolBar("ForgeAI")
        toolbar.setMovable(False)
        toolbar.addWidget(QLabel("  ForgeAI — lokale KI-Entwicklungsumgebung"))
        self.addToolBar(toolbar)
        self.sidebar = Sidebar()
        self.chat_view = ChatView()
        self.project_panel = ProjectPanel()
        self.file_viewer = FileViewer()
        self.terminal = TerminalPanel()
        self.input_bar = InputBar()
        self.sidebar.new_chat_requested.connect(self.new_chat)
        self.sidebar.delete_chats_requested.connect(self.delete_chats)
        self.sidebar.delete_all_chats_requested.connect(self.delete_all_chats)
        self.sidebar.chat_selected.connect(self.load_chat)
        self.input_bar.submitted.connect(self.send_message)
        self.project_panel.open_project_requested.connect(self.open_project)
        self.project_panel.refresh_requested.connect(self.refresh_index)
        self.project_panel.file_open_requested.connect(self.open_file)
        self.project_panel.ai_access_grant_requested.connect(self.grant_ai_access)
        self.project_panel.ai_access_revoke_requested.connect(self.revoke_ai_access)
        self.project_panel.ai_access_grant_many_requested.connect(self.grant_ai_access_many)
        self.project_panel.ai_access_revoke_many_requested.connect(self.revoke_ai_access_many)
        center_split = QSplitter(Qt.Orientation.Vertical)
        center_split.addWidget(self.chat_view)
        center_split.addWidget(self.file_viewer)
        center_split.setSizes([430, 260])
        top = QSplitter(Qt.Orientation.Horizontal)
        top.addWidget(self.sidebar)
        top.addWidget(center_split)
        top.addWidget(self.project_panel)
        top.setSizes([240, 900, 380])
        lower = QSplitter(Qt.Orientation.Vertical)
        lower.addWidget(top)
        lower.addWidget(self.terminal)
        lower.setSizes([660, 200])
        central = QWidget()
        layout = QVBoxLayout(central)
        layout.setContentsMargins(6, 6, 6, 6)
        layout.addWidget(lower, 1)
        layout.addWidget(self.input_bar)
        self.setCentralWidget(central)
        self.project_status = QLabel("Projekt: keines")
        self.model_status = QLabel()
        self.backend_status = QLabel("Backend: Ollama lokal")
        self.ollama_status = QLabel("Ollama: unbekannt")
        self.git_status = QLabel("Git: –")
        self.file_status = QLabel("Dateien: 0")
        self.workspace_status = QLabel("Workspace: lokal")
        self.agent_status = QLabel("Agent: bereit")
        self.index_status = QLabel("Index: bereit")
        for label in (self.workspace_status, self.agent_status, self.project_status, self.index_status, self.backend_status, self.ollama_status, self.model_status, self.git_status, self.file_status):
            self.statusBar().addPermanentWidget(label)
        self._update_status()

    def _build_menus(self) -> None:
        agent_menu = self.menuBar().addMenu("Agent")
        self.agent_review_action = QAction("Plan & Review aktiv", self)
        self.agent_review_action.setCheckable(True)
        self.agent_review_action.setChecked(self.agent_review_enabled)
        self.agent_review_action.triggered.connect(self._set_agent_review_enabled)
        agent_menu.addAction(self.agent_review_action)

        file_menu = self.menuBar().addMenu("Datei")
        file_menu.addAction("Projekt öffnen", self.choose_project)
        file_menu.addAction("Projekt schließen", self.close_project)
        self.recent_menu = file_menu.addMenu("Zuletzt geöffnet")
        self.recent_menu.aboutToShow.connect(self.populate_recent_projects)
        file_menu.addAction("Einstellungen", self.show_settings)
        file_menu.addSeparator()
        file_menu.addAction("Beenden", self.close)
        project_menu = self.menuBar().addMenu("Projekt")
        project_menu.addAction("Projekt analysieren", self.analyze_project)
        project_menu.addAction("Index aktualisieren", self.refresh_index)
        project_menu.addAction("Favorit umschalten", self.toggle_favorite)
        project_menu.addAction("Projektinformationen", self.show_project_information)
        tools_menu = self.menuBar().addMenu("Werkzeuge")
        tools_menu.addAction("Terminal", self.focus_terminal)
        tools_menu.addAction("Aufgaben", self.show_tasks)
        tools_menu.addAction("Logs", self.show_logs)
        ai_menu = self.menuBar().addMenu("KI")
        ai_menu.addAction("Modell wechseln", self.show_settings)
        ai_menu.addAction("Systemprompt", self.show_system_prompt)
        ai_menu.addAction("Kontext anzeigen", self.show_context)
        ollama_menu = self.menuBar().addMenu("Ollama")
        ollama_menu.addAction("Projekt analysieren mit Ollama", self.analyze_project_with_ollama)

    def _apply_theme(self) -> None:
        font_size = self._setting("font_size", "10")
        theme = self._setting("theme", "Dunkel")
        if theme == "Hell":
            self.setStyleSheet(f"QWidget {{ font-family: 'Segoe UI'; font-size: {font_size}pt; }}")
            return
        self.setStyleSheet(f"""
            QMainWindow, QWidget {{ background: #171a1f; color: #e6edf3; font-family: 'Segoe UI'; font-size: {font_size}pt; }}
            QTextEdit, QPlainTextEdit, QTextBrowser, QListWidget, QTreeView, QLineEdit {{ background: #20252b; color: #e6edf3; border: 1px solid #343b45; border-radius: 5px; padding: 5px; }}
            QPushButton {{ background: #2d6cdf; color: white; border: 0; border-radius: 5px; padding: 7px 10px; }}
            QPushButton:hover {{ background: #3c7aed; }} QPushButton:disabled {{ background: #4b5563; }}
            QToolBar, QMenuBar, QStatusBar {{ background: #20252b; border-bottom: 1px solid #343b45; spacing: 8px; }}
            #userMessage {{ background: #1e3a5f; border-radius: 8px; }} #assistantMessage {{ background: #20252b; border-radius: 8px; }}
        """)

    def _setting(self, key: str, default: str) -> str:
        row = self.database.fetchone("SELECT value FROM settings WHERE key=?", (key,))
        return row["value"] if row else default

    def _save_setting(self, key: str, value: str) -> None:
        self.database.execute("INSERT INTO settings(key,value) VALUES(?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value", (key, value))

    def _context_hard_limit(self) -> int | None:
        if self._setting("context_mode", "custom").strip().lower() == "auto":
            return None

        try:
            value = int(self._setting("context_limit", "16000"))
        except (TypeError, ValueError):
            value = 16000

        return max(8192, min(value, 131072))

    def _restore_window(self) -> None:
        saved = self._setting("window_geometry", "")
        if saved:
            self.restoreGeometry(base64.b64decode(saved.encode("ascii")))

    def closeEvent(self, event) -> None:  # noqa: N802 - Qt API name
        self._save_setting("window_geometry", base64.b64encode(bytes(self.saveGeometry())).decode("ascii"))
        event.accept()

    def refresh_chats(self) -> None:
        self.sidebar.populate(self.history.list_chats(), self.chat_id)

    def _restore_chat(self) -> None:
        """Restore the most recently updated chat without creating an empty one."""
        chats = self.history.list_chats()

        if chats:
            self.load_chat(chats[0]["id"])
            return

        self.chat_id = None
        self.chat_view.clear_messages()
        self.refresh_chats()

    def new_chat(self) -> None:
        self.chat_id = self.history.create_chat()
        self.chat_view.clear_messages()
        self.refresh_chats()

    def delete_chats(self, chat_ids: list[int]) -> None:
        if not chat_ids:
            return

        count = len(chat_ids)
        answer = QMessageBox.question(
            self,
            "Chats löschen",
            f"Sollen {count} ausgewählte Chats wirklich gelöscht werden?",
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
            QMessageBox.StandardButton.No,
        )

        if answer != QMessageBox.StandardButton.Yes:
            return

        current_deleted = self.chat_id in chat_ids if self.chat_id is not None else False
        self.history.delete_chats(chat_ids)

        remaining = self.history.list_chats()

        if current_deleted:
            if remaining:
                self.load_chat(remaining[0]["id"])
            else:
                self.chat_id = None
                self.chat_view.clear_messages()
                self.refresh_chats()
        else:
            self.refresh_chats()

    def delete_all_chats(self) -> None:
        chats = self.history.list_chats()
        if not chats:
            return

        answer = QMessageBox.question(
            self,
            "Alle Chats löschen",
            "Sollen wirklich ALLE Chats inklusive ihrer Nachrichten gelöscht werden?",
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
            QMessageBox.StandardButton.No,
        )

        if answer != QMessageBox.StandardButton.Yes:
            return

        self.history.delete_all_chats()
        self.chat_id = None
        self.chat_view.clear_messages()
        self.refresh_chats()

    def load_chat(self, chat_id: int) -> None:
        self.chat_id = chat_id
        self.chat_view.clear_messages()
        for message in self.history.messages(chat_id):
            self.chat_view.add_message(message["role"], message["content"])

    def send_message(self, text: str) -> None:
        if self.worker and self.worker.isRunning() or self.chat_id is None:
            return

        is_change_request = self._is_change_request(text)
        self._stream_is_action = self._action_response_format(text) is not None

        if is_change_request:
            self.history.add_message(self.chat_id, "user", text)
            self._pending_user_request = text
            self.chat_view.add_message("user", text)
            self.chat_view.add_message("assistant", "")

            project_context = self._build_agent_project_context()
            self._start_agent_workflow(text, project_context)
            return

        if self._pending_change_previews and self._is_change_confirmation(text):
            self.history.add_message(self.chat_id, "user", text)
            self.chat_view.add_message("user", text)
            self.chat_view.add_message("assistant", "")

            previews = self._pending_change_previews
            self._pending_change_previews = None

            success, message = self._apply_change_previews(previews)
            status_title = (
                "Änderungen angewendet"
                if success
                else "Änderungen nicht angewendet"
            )
            result_message = f"**{status_title}:** {message}"

            if self.chat_view.pending:
                self.chat_view.pending.set_content(result_message)

            if self.chat_id is not None:
                self.history.add_message(
                    self.chat_id,
                    "assistant",
                    result_message,
                )

            self.refresh_chats()
            return
        self.history.add_message(self.chat_id, "user", text)
        self._pending_user_request = text
        self._stream_is_action = self._action_response_format(text) is not None
        print("[DEBUG action] request=", repr(text))
        print("[DEBUG action] stream_is_action=", self._stream_is_action)
        if len(self.history.messages(self.chat_id)) == 1:
            self.history.title_chat(self.chat_id, text[:42])
        self.chat_view.add_message("user", text)
        self.chat_view.add_message("assistant", "")
        is_analysis_request = self._is_analysis_request(text)

        if is_analysis_request:
            response_format = self._analysis_response_format(text)
        else:
            response_format = self._action_response_format(text)

        is_prompt_request = (
            not is_analysis_request
            and response_format is None
            and is_creative_prompt_request(text)
        )
        if is_analysis_request:
            system_content = SYSTEM_PROMPT + self._analysis_instructions()
        elif response_format is not None:
            system_content = SYSTEM_PROMPT + self._change_action_instructions()
        elif is_prompt_request:
            system_content = SYSTEM_PROMPT + "\n\n" + PROMPT_CREATION_INSTRUCTIONS
        else:
            system_content = SYSTEM_PROMPT

        model_context_length = self.ollama.get_context_length(
            self.ollama_url,
            self.model,
        ) or 32_768

        context_plan = self.ollama.recommend_context_length(
            self.ollama_url,
            self.model,
            model_context_length,
            hard_limit=self._context_hard_limit(),
        )

        num_ctx = context_plan["recommended_context"]

        # Reserve part of the context for system instructions, chat history
        # and model output. Keep project files inside the remaining budget.
        project_context_tokens = max(4_096, int(num_ctx * 0.55))
        per_file_tokens = max(
            2_048,
            min(project_context_tokens // 2, 8_192),
        )

        # Standalone creative prompts must not absorb unrelated approved source
        # files as instructions or waste context on an active coding project.
        if is_prompt_request and is_standalone_prompt_request(text):
            context, included_files = "", []
        else:
            context, included_files = self.ai_context.build(
                self.workspace.active_project,
                max_context_tokens=project_context_tokens,
                max_file_tokens=per_file_tokens,
                exclude_noise=is_analysis_request,
                request=text if is_analysis_request else None,
                include_structure=is_analysis_request,
            )

        self.logger.info(
            "Model %s: native_context=%s, recommended_context=%s, "
            "project_context=%s, per_file=%s, gpu_vram_total=%s, "
            "ram_total=%s, ram_available=%s, model_size=%s, reason=%s",
            self.model,
            context_plan["context_length"],
            context_plan["recommended_context"],
            project_context_tokens,
            per_file_tokens,
            context_plan["gpu_vram_total_bytes"],
            context_plan["system_ram_total_bytes"],
            context_plan["system_ram_available_bytes"],
            context_plan["model_size_bytes"],
            context_plan["reason"],
        )
        self.logger.info("Approved files sent to Ollama: %s", included_files)
        if context:
            system_content += "\n\n" + context
            self.logger.info("Sent %s approved local files to Ollama", len(included_files))

        messages = [{"role": "system", "content": system_content}]
        if is_prompt_request and is_standalone_prompt_request(text):
            # The previous assistant may have refused this *unrelated* task.
            # The new brief should not inherit that refusal as a few-shot example.
            messages.append({"role": "user", "content": text})
        else:
            messages += [
                {"role": row["role"], "content": row["content"]}
                for row in self.history.messages(self.chat_id)
            ]
        self.worker = self.ollama.stream_chat(
            self.ollama_url,
            self.model,
            messages,
            response_format,
            num_ctx=num_ctx,
        )

        if not self._stream_is_action:
            self.worker.token_received.connect(self.chat_view.append_stream)
        self.worker.completed.connect(self._response_done)
        self.worker.failed.connect(self._response_failed)
        self.input_bar.set_busy(True)
        self.worker.start()

    def _set_agent_review_enabled(self, enabled: bool) -> None:
        self.agent_review_enabled = bool(enabled)
        self.agent_status.setText(
            "Agent: Plan & Review aktiv" if enabled else "Agent: Review aus"
        )
        self._save_setting("agent_review_enabled", "true" if enabled else "false")

    def _is_change_request(self, request: str) -> bool:
        return is_project_change_request(request)

    def _build_agent_project_context(self, *, refresh_budget: bool = True) -> str:
        num_ctx = self._agent_num_ctx
        if refresh_budget or num_ctx is None:
            model_context_length = self.ollama.get_context_length(
                self.ollama_url,
                self.model,
            ) or 32_768
            context_plan = self.ollama.recommend_context_length(
                self.ollama_url,
                self.model,
                model_context_length,
                hard_limit=self._context_hard_limit(),
            )
            num_ctx = context_plan["recommended_context"]
        project_context_tokens = max(4_096, int(num_ctx * 0.55))
        per_file_tokens = max(
            2_048,
            min(project_context_tokens // 2, 8_192),
        )
        context, included_files = self.ai_context.build(
            self.workspace.active_project,
            max_context_tokens=project_context_tokens,
            max_file_tokens=per_file_tokens,
            exclude_noise=True,
            include_structure=True,
        )
        self._agent_num_ctx = num_ctx
        self._agent_project_context = context or ""
        self.logger.info(
            "Agent context: files=%s, project_context_tokens=%s, per_file_tokens=%s",
            len(included_files),
            project_context_tokens,
            per_file_tokens,
        )
        return self._agent_project_context

    def _set_agent_status(self, text: str) -> None:
        self.agent_status.setText(f"Agent: {text}")

    def _start_agent_workflow(self, request: str, project_context: str) -> None:
        if self.chat_id is None:
            return

        self._pending_user_request = request
        self._agent_project_context = project_context
        self._agent_task = AgentTask(
            task_id=uuid.uuid4().hex,
            user_request=request,
            project_path=(
                str(self.workspace.active_project)
                if self.workspace.active_project
                else None
            ),
        )

        run = AgentRun(task_id=self._agent_task.task_id)
        self._agent_reality = AgentReality.from_task_and_run(
            task=self._agent_task,
            run=run,
            agent_id="forgeai-agent",
            provider="ollama",
            model=self.model,
            role="orchestrator",
            run_id=uuid.uuid4().hex,
        )

        if self.workspace.active_project:
            RealityCollector(self.workspace.analyzer).collect_project(
                self._agent_reality,
                self.workspace.active_project,
            )

        self.chat_view.add_message("assistant", "")
        self.input_bar.set_busy(True)
        self._set_agent_status("plane")

        self._agent_worker = AgentWorkflowWorker(
            task=self._agent_task,
            project_context=project_context,
            model=self.model,
            base_url=self.ollama_url,
            review_enabled=self.agent_review_enabled,
            num_ctx=self._agent_num_ctx,
            run=run,
            reality=self._agent_reality,
            parent=self,
        )
        self._agent_worker.completed.connect(self._agent_workflow_finished)
        self._agent_worker.failed.connect(self._agent_workflow_failed)
        self._agent_worker.start()

    def _agent_workflow_failed(self, error: str) -> None:
        self.input_bar.set_busy(False)
        self._set_agent_status("Fehler")
        if self.chat_view.pending:
            self.chat_view.pending.set_content(
                f"**Agent-Fehler:** {error}"
            )
        self.logger.error("Agent workflow failed: %s", error)

    def _agent_workflow_finished(
        self,
        orchestrator: AgentOrchestrator,
        task: AgentTask,
        plan,
    ) -> None:
        self._agent_worker = None
        self._agent_orchestrator = orchestrator
        self._agent_task = task
        self._agent_plan = plan
        self._request_agent_plan_approval(
            plan,
            dialog_title="Agentenplan freigeben",
            dialog_intro=(
                "Der Agent hat Planung und Review abgeschlossen."
            ),
        )

    def _start_agent_coder_stream(self) -> None:
        if self.chat_id is None or self._agent_plan is None:
            return

        plan_json = json.dumps(
            {
                "summary": self._agent_plan.summary,
                "proposed_changes": self._agent_plan.proposed_changes,
                "rationale": self._agent_plan.rationale,
            },
            ensure_ascii=False,
            indent=2,
        )

        system_content = (
            SYSTEM_PROMPT
            + self._change_action_instructions()
            + "\n\nDu arbeitest jetzt auf Basis dieses freigegebenen Agentenplans."
            + "\nDer Plan ist verbindlich. Setze ihn über die vorhandenen "
            + "strukturierten Dateiaktionen um.\n\n"
            + "AGENT_PLAN:\n"
            + plan_json
        )

        if self._agent_project_context:
            system_content += "\n\nPROJECT_CONTEXT:\n" + self._agent_project_context

        messages = [{"role": "system", "content": system_content}]
        messages += [
            {"role": row["role"], "content": row["content"]}
            for row in self.history.messages(self.chat_id)
        ]

        self.chat_view.add_message("assistant", "")
        self._pending_change_previews = None
        self._stream_is_action = True

        self.worker = self.ollama.stream_chat(
            self.ollama_url,
            self.model,
            messages,
            self._action_response_format(self._pending_user_request),
            num_ctx=self._agent_num_ctx,
        )
        self.worker.completed.connect(self._response_done)
        self.worker.failed.connect(self._response_failed)
        self.input_bar.set_busy(True)
        self.worker.start()

    def _response_done(self) -> None:
        try:
            sender = self.sender()
        except RuntimeError:
            sender = None

        if sender is not None and sender is not self.worker:
            self.logger.warning("Ignoring stale Ollama worker completion.")
            return

        if not self.worker:
            self._response_failed("Keine Ollama-Antwort erhalten.")
            return

        raw_content = self.worker.content

        if (
            self._stream_is_action
            and not self._is_analysis_request(
                self._pending_user_request or ""
            )
        ):
            content, previews = self._prepare_model_changes(raw_content)
        elif self._is_analysis_request(getattr(self, "_pending_user_request", "")):
            content = self._validate_analysis_response(raw_content)
            previews = []
        else:
            content, previews = raw_content, []

        if self.chat_view.pending:
            self.chat_view.pending.set_content(content)

        if content and self.chat_id is not None:
            self.history.add_message(
                self.chat_id,
                "assistant",
                content,
            )

        self.input_bar.set_busy(False)
        self.refresh_chats()

        if previews:
            self._pending_change_previews = previews
            self.chat_view.add_change_proposal(
                previews,
                lambda: self._apply_change_previews(previews),
            )

        self._stream_is_action = False
    def _validate_analysis_response(self, response: str) -> str:
        """Validate structured analysis and claims against deterministic evidence."""
        project = self.workspace.active_project

        if not project:
            return response

        evidence = ProjectEvidence.from_analyzer(
            self.workspace.analyzer,
            project,
        )

        try:
            parsed = json.loads(response)
        except (TypeError, json.JSONDecodeError):
            parsed = None

        if isinstance(parsed, dict):
            if "analysis" in parsed and "claims" in parsed:
                return self.evidence_validator.render_structured_analysis(
                    parsed,
                    evidence,
                )

            if "claims" in parsed:
                return self.evidence_validator.render_claims(
                    self.evidence_validator.claims_from_json(response),
                    evidence,
                )

        return self.evidence_validator.rewrite_analysis(
            response,
            evidence,
        )

    @staticmethod
    def _is_change_confirmation(request: str) -> bool:
        """Detect explicit chat confirmations for the currently pending preview."""
        normalized = " ".join(request.casefold().strip().split())

        confirmations = (
            "fuehre das aus",
            "\u0066\u00fchre das aus",

            "fuehre die aenderung aus",
            "\u0066\u00fchre die \u00e4nderung aus",

            "fuehre die aenderungen aus",
            "\u0066\u00fchre die \u00e4nderungen aus",

            "fuehre es aus",
            "\u0066\u00fchre es aus",

            "wende das an",
            "wende die aenderung an",
            "wende die \u00e4nderung an",
            "wende die aenderungen an",
            "wende die \u00e4nderungen an",

            "anwenden",
            "bitte anwenden",

            "aenderungen anwenden",
            "\u00e4nderungen anwenden",
            "aenderung anwenden",
            "\u00e4nderung anwenden",

            "aendere das",
            "\u00e4ndere das",

            "mach das",
            "mach es",
            "setz das um",
            "setze das um",
            "umsetzen",

            "uebernehmen",
            "\u00fcbernehmen",
            "ja uebernehmen",
            "ja \u00fcbernehmen",
            "bitte uebernehmen",
            "bitte \u00fcbernehmen",

            "bestaetigt",
            "best\u00e4tigt",
            "einverstanden",
            "genehmigt",
            "freigegeben",
        )

        return normalized in confirmations

    @staticmethod
    def _is_analysis_request(request: str) -> bool:
        """Detect requests that explicitly ask for analysis without file changes."""
        normalized = request.casefold().strip()

        analysis_verbs = (
            "analysiere",
            "analysier",
            "untersuche",
            "prüfe",
            "pruefe",
            "erkläre",
            "erklaere",
            "beschreibe",
            "bewerte",
            "überprüfe",
            "ueberpruefe",
        )

        return any(
            normalized.startswith(verb + " ")
            or normalized == verb
            for verb in analysis_verbs
        )

    @staticmethod
    def _analysis_response_format(request: str) -> dict | None:
        """Return the structured JSON schema used by analysis requests."""
        if not MainWindow._is_analysis_request(request):
            return None

        from forgeai.core.evidence_validator import ClaimType

        return {
            "type": "object",
            "properties": {
                "analysis": {
                    "type": "object",
                    "properties": {
                        "summary": {
                            "type": "string",
                        },
                        "architecture": {
                            "type": "string",
                        },
                        "components": {
                            "type": "array",
                            "items": {"type": "string"},
                        },
                        "flow": {
                            "type": "string",
                        },
                        "observations": {
                            "type": "array",
                            "items": {"type": "string"},
                        },
                    },
                    "required": [
                        "summary",
                        "architecture",
                        "components",
                        "flow",
                        "observations",
                    ],
                },
                "claims": {
                    "type": "array",
                    "items": {
                        "type": "object",
                        "properties": {
                            "claim_type": {
                                "type": "string",
                                "enum": [
                                    claim_type.value
                                    for claim_type in ClaimType
                                ],
                            },
                            "statement": {
                                "type": "string",
                            },
                            "target": {
                                "type": ["string", "null"],
                            },
                            "source_file": {
                                "type": ["string", "null"],
                            },
                            "source_line": {
                                "type": ["integer", "null"],
                            },
                            "category": {
                                "type": "string",
                                "enum": [
                                    "error",
                                    "risk",
                                    "improvement",
                                    "analysis",
                                ],
                            },
                        },
                        "required": [
                            "claim_type",
                            "statement",
                            "target",
                            "source_file",
                            "source_line",
                            "category",
                        ],
                    },
                },
            },
            "required": [
                "analysis",
                "claims",
            ],
        }

    @staticmethod
    def _analysis_instructions() -> str:
        return """
ANALYSEMODUS

Die Benutzeranfrage verlangt eine technische Analyse des aktuell bereitgestellten
Projektkontexts. Es dürfen keine Dateien verändert werden.

Die Antwort besteht aus zwei getrennten Bereichen:

1. analysis
   Enthält die eigentliche technische Projektanalyse.
   Diese Analyse beschreibt den beobachteten Projektzustand, die Architektur,
   Komponenten, Abläufe und sonstige technische Beobachtungen.

2. claims
   Enthält zusätzliche prüfbare Behauptungen.
   Claims sind Kandidaten und noch keine bewiesenen Fehler.

ForgeAI prüft jeden Claim anschließend gegen deterministische lokale
Projekt-Evidence und übernimmt nur entsprechend validierte Aussagen als
belegt in den finalen Bericht.

VERWENDE AUSSCHLIESSLICH INFORMATIONEN AUS DEM BEREITGESTELLTEN KONTEXT.

ANALYSIS:

- summary: kurze Zusammenfassung des Projekts und seines aktuellen Zustands
- architecture: Beschreibung der erkannten Architektur
- components: wichtige erkannte Komponenten, Module oder Klassen
- flow: Beschreibung wichtiger Daten- oder Ablaufwege
- observations: zusätzliche technische Beobachtungen

CLAIMS:

ERLAUBTE CLAIM-TYPEN:
- file_exists
- file_missing
- function_exists
- class_exists
- module_exists
- import_exists
- dependency_exists
- syntax_error
- duplicate_event_handler
- architecture_problem
- unknown

FÜR JEDEN CLAIM:
- statement: kurze verständliche Beschreibung
- claim_type: einer der erlaubten Claim-Typen
- target: das konkret zu prüfende Objekt
- source_file: konkrete Datei, wenn bekannt, sonst null
- source_line: konkrete Zeile, wenn bekannt, sonst null
- category: error, risk, improvement oder analysis

REGELN:
- Erfinde niemals target, Datei, Funktion, Klasse, Import, Modul oder Zeile.
- Verwende source_file nur, wenn diese Datei im Kontext tatsächlich vorhanden ist.
- Verwende source_line nur, wenn die Zeile im bereitgestellten Kontext konkret ermittelbar ist.
- Ein möglicher Fehler ist nur ein Kandidaten-Claim, niemals ein bewiesener Fehler.
- Ein Risiko ist kein sicherer Fehler.
- Eine Verbesserung ist kein Fehler.
- Fehlende Evidence bedeutet nicht automatisch, dass eine Behauptung falsch ist.
- Die endgültige Einstufung übernimmt ForgeAI.
- Bei duplicate_event_handler muss target die konkrete Ereignisart enthalten.
- Bei syntax_error muss target die konkret beobachtete Fehlermeldung enthalten.
- Bei dependency_exists muss target die konkrete Beziehung enthalten.

AUSGABE:

{
  "analysis": {
    "summary": "...",
    "architecture": "...",
    "components": ["..."],
    "flow": "...",
    "observations": ["..."]
  },
  "claims": [
    {
      "claim_type": "duplicate_event_handler",
      "statement": "Doppelte MOUSEBUTTONDOWN-Verarbeitung wurde festgestellt.",
      "target": "pygame.MOUSEBUTTONDOWN",
      "source_file": "main.py",
      "source_line": null,
      "category": "error"
    }
  ]
}

Wenn keine sinnvollen Claims erzeugt werden können:

{
  "analysis": {
    "summary": "...",
    "architecture": "...",
    "components": [],
    "flow": "...",
    "observations": []
  },
  "claims": []
}

Keine Markdown-Codeblöcke.
Keine zusätzlichen Erklärungen außerhalb des JSON.
Keine JSON-actions.
Keine ChangePreview.
Keine Dateiänderungsbefehle.
Keine selbst erfundenen Beweise.
"""

    def _action_response_format(self, request: str) -> dict | None:
        """Force structured local-model output for requests that change project files."""
        if self._is_analysis_request(request) or not self._is_change_request(request):
            return None

        if not self.workspace.active_project or self.workspace.project_mode() not in {
            ProjectMode.WRITE_WITH_CONFIRMATION,
            ProjectMode.AUTO_WRITE,
        }:
            return None

        normalized = request.casefold()

        change_verbs = (
            "erstelle",
            "erstell",
            "anlegen",
            "anlege",
            "\u00e4ndere",
            "aendere",
            "bearbeite",
            "\u00fcberschreibe",
            "ueberschreibe",
            "\u00e4ndern",
            "aendern",
            "f\u00fcge",
            "fuege",
            "erg\u00e4nze",
            "ergaenze",
            "verbessere",
            "implementiere",
            "ersetze",
            "ersetzen",
            "entferne",
            "entfern",
            "l\u00f6sche",
            "loesche",
            "behebe",
            "repariere",
            "aktualisiere",
            "\u00fcberarbeite",
            "ueberarbeite",
        )

        if not any(verb in normalized for verb in change_verbs):
            return None

        return {
            "type": "object",
            "properties": {
                "actions": {
                    "type": "array",
                    "minItems": 1,
                    "items": {
                        "oneOf": [
                            {
                                "type": "object",
                                "properties": {
                                    "operation": {
                                        "type": "string",
                                        "enum": ["create"],
                                    },
                                    "path": {"type": "string"},
                                    "content": {"type": "string"},
                                },
                                "required": [
                                    "operation",
                                    "path",
                                    "content",
                                ],
                            },
                            {
                                "type": "object",
                                "properties": {
                                    "operation": {
                                        "type": "string",
                                        "enum": ["create_directory"],
                                    },
                                    "path": {"type": "string"},
                                },
                                "required": [
                                    "operation",
                                    "path",
                                ],
                            },
                            {
                                "type": "object",
                                "properties": {
                                    "operation": {
                                        "type": "string",
                                        "enum": ["replace"],
                                    },
                                    "path": {"type": "string"},
                                    "old": {"type": "string"},
                                    "new": {"type": "string"},
                                },
                                "required": [
                                    "operation",
                                    "path",
                                    "old",
                                    "new",
                                ],
                            },
                            {
                                "type": "object",
                                "properties": {
                                    "operation": {
                                        "type": "string",
                                        "enum": ["insert_before"],
                                    },
                                    "path": {"type": "string"},
                                    "anchor": {"type": "string"},
                                    "content": {"type": "string"},
                                },
                                "required": [
                                    "operation",
                                    "path",
                                    "anchor",
                                    "content",
                                ],
                            },
                            {
                                "type": "object",
                                "properties": {
                                    "operation": {
                                        "type": "string",
                                        "enum": ["insert_after"],
                                    },
                                    "path": {"type": "string"},
                                    "anchor": {"type": "string"},
                                    "content": {"type": "string"},
                                },
                                "required": [
                                    "operation",
                                    "path",
                                    "anchor",
                                    "content",
                                ],
                            },
                        ],
                    },
                },
            },
            "required": ["actions"],
        }

    def _change_action_instructions(self) -> str:
        """Return instructions for structured file-change actions."""
        if (
            not self.workspace.active_project
            or self.workspace.project_mode()
            not in {
                ProjectMode.WRITE_WITH_CONFIRMATION,
                ProjectMode.AUTO_WRITE,
            }
        ):
            return (
                "\n\nDu darfst keine Dateien \u00e4ndern; "
                "liefere nur Erkl\u00e4rungen oder Vorschl\u00e4ge."
            )

        return """
WICHTIG: Wenn eine Datei erstellt oder ge\u00e4ndert werden soll, MUSST du eine
JSON-Antwort mit einer actions-Liste ausgeben.

Das Format ist immer:

{
  "actions": [
    {
      "operation": "insert_after",
      "path": "datei.py",
      "anchor": "bestehender Code",
      "content": "neuer Code"
    }
  ]
}

Erlaubte Operationen:
- replace: \u00e4ndert einen vorhandenen Bereich einer bestehenden Datei.
- insert_before: f\u00fcgt neuen Code unmittelbar vor einem eindeutig vorhandenen anchor ein.
- insert_after: f\u00fcgt neuen Code unmittelbar nach einem eindeutig vorhandenen anchor ein.
- create: erstellt eine neue Datei.
- create_directory: erstellt ein neues Verzeichnis.

Bei einer reinen Code-Erg\u00e4nzung in einer bestehenden Datei verwendest du
insert_before oder insert_after.

Verwende replace nur dann, wenn vorhandener Code tats\u00e4chlich ersetzt oder
ver\u00e4ndert werden soll.


Der Benutzer liefert den Originalcode und die zu ersetzende Textstelle nicht
notwendigerweise selbst. Wenn der relevante Dateiinhalt bereits im bereitgestellten
Projektkontext enthalten ist, analysiere ihn selbst und ermittle daraus die
erforderliche replace-Aktion.

Regeln f\u00fcr jede replace-Aktion:

- old muss exakt und unver\u00e4ndert im aktuell bereitgestellten Dateiinhalt vorkommen.
- old muss ein zusammenh\u00e4ngender Ausschnitt sein.
- old so klein wie m\u00f6glich halten, aber gro\u00df genug, um die Zielstelle eindeutig
  zu identifizieren.
- old muss genau eine Fundstelle im aktuellen Dateiinhalt haben.
- Wenn ein geeigneter old-Block nicht eindeutig bestimmt werden kann, erstelle keine
  unsichere Aktion.
- Erfinde niemals Dateiinhalt, der nicht im bereitgestellten Kontext vorhanden ist.
- Ver\u00e4ndere nur die Dateien, die f\u00fcr die Benutzeranforderung wirklich notwendig sind.
- Bestehende, bereits korrekte Tests oder Funktionen d\u00fcrfen nicht unn\u00f6tig ersetzt werden.

Regeln f\u00fcr insert_before und insert_after:

- anchor muss exakt und unver\u00e4ndert im aktuell bereitgestellten Dateiinhalt vorkommen.
- anchor muss ein zusammenh\u00e4ngender Ausschnitt sein.
- anchor muss genau eine Fundstelle im aktuellen Dateiinhalt haben.
- Wenn der anchor nicht eindeutig bestimmt werden kann, erstelle keine unsichere Aktion.
- content enth\u00e4lt ausschlie\u00dflich den neu einzuf\u00fcgenden Code.
- Verwende keine k\u00fcnstliche replace-Aktion, wenn tats\u00e4chlich nur Code erg\u00e4nzt werden soll.

Bei create:
- Verwende einen relativen Pfad innerhalb des ge\u00f6ffneten Projekts.
- Der Pfad muss eine neue Datei bezeichnen.

Bei create_directory:
- Verwende einen relativen Pfad innerhalb des ge\u00f6ffneten Projekts.

Gib ausschlie\u00dflich valides JSON entsprechend dem vorgegebenen Schema aus.
Keine Markdown-Codebl\u00f6cke und keine zus\u00e4tzlichen Erkl\u00e4rungen au\u00dferhalb des JSON.
"""

    def _prepare_model_changes(self, response: str) -> tuple[str, list[ChangePreview]]:
        """Turn model actions into validated previews without writing any files."""
        if self._is_analysis_request(self._pending_user_request or ""):
            print("[DEBUG prepare] SKIPPED: analysis request")
            return response, []

        project = self.workspace.active_project
        print("[DEBUG prepare] project=", project)
        print("[DEBUG prepare] mode=", self.workspace.project_mode())

        if not project or self.workspace.project_mode() not in {
            ProjectMode.WRITE_WITH_CONFIRMATION,
            ProjectMode.AUTO_WRITE,
        }:
            print("[DEBUG prepare] EARLY RETURN: project/mode")
            return response, []

        visible, previews, errors = extract_change_previews(
            response,
            WorkspaceTools(project, self.workspace.filesystem),
        )

        print("[DEBUG prepare] previews=", len(previews))
        print("[DEBUG prepare] errors=", errors)

        permitted_previews: list[ChangePreview] = []

        for preview in previews:
            if self._is_ai_control_file(preview.path):
                errors.append(
                    f"Die KI-Schreibfunktion selbst darf nicht verändert werden: "
                    f"{preview.path.name}."
                )
                continue

            permitted_previews.append(preview)

        if (
            self.workspace.project_mode() == ProjectMode.AUTO_WRITE
            and permitted_previews
        ):
            success, message = self._apply_change_previews(
                permitted_previews
            )
            visible += f"\n\n*{message}*"
            if success:
                permitted_previews = []

        if errors:
            visible += (
                "\n\n**DateiÄnderung nicht vorbereitet:** "
                + " | ".join(errors)
            )

        return visible, permitted_previews

    def _apply_change_previews(self, previews: list[ChangePreview]) -> tuple[bool, str]:
        """Apply user-approved previews through the existing WorkspaceTools gateway."""
        if previews is self._pending_change_previews:
            self._pending_change_previews = None

        project = self.workspace.active_project
        if not project:
            return False, "Kein Projekt geöffnet."
        applied = 0
        errors: list[str] = []
        tools = WorkspaceTools(project, self.workspace.filesystem)
        for preview in previews:
            if self._is_ai_control_file(preview.path):
                errors.append(f"Die KI-Schreibfunktion selbst darf nicht verändert werden: {preview.path.name}.")
                continue
            try:
                self.workspace.grant_session_access(preview.path)
                if not self.workspace.is_ai_path_granted(preview.path):
                    errors.append(f"Keine KI-Freigabe für {preview.path.relative_to(project)}.")
                    continue
                tools.apply(preview, confirmed=True)
                applied += 1
            except (OSError, PermissionError) as error:
                errors.append(str(error))
        if errors:
            return False, f"{applied} Änderung(en) angewendet; Fehler: {' | '.join(errors)}"

        if applied:
            self.refresh_index()

            if (
                self._agent_orchestrator is not None
                and self._agent_orchestrator.run.state == AgentState.EXECUTING
                and self._agent_verification_worker is None
            ):
                self._start_agent_verification()

        return True, f"{applied} Dateiänderung(en) wurden angewendet."

    def _start_agent_verification(self) -> None:
        """Startet die technische Verifikation nach einem Agent-Apply."""
        if self._agent_orchestrator is None:
            return

        project = self.workspace.active_project
        if not project:
            self._set_agent_status("Kein Projekt für Verifikation")
            return

        if self._agent_verification_worker is not None:
            return

        try:
            self._agent_orchestrator.begin_testing()
        except RuntimeError as error:
            self.logger.error(
                "Agent verification could not start: %s",
                error,
            )
            self._set_agent_status("Verifikation nicht gestartet")
            return

        worker = AgentVerificationWorker(project, parent=self)
        self._agent_verification_worker = worker
        worker.completed.connect(self._agent_verification_finished)
        worker.failed.connect(self._agent_verification_failed)
        worker.start()

    def _agent_verification_finished(
        self,
        success: bool,
        exit_code: int,
        test_output: str,
    ) -> None:
        worker = self._agent_verification_worker
        self._agent_verification_worker = None

        if worker is not None:
            worker.deleteLater()

        orchestrator = self._agent_orchestrator
        if orchestrator is None:
            return

        try:
            state = orchestrator.handle_verification_result(
                success,
                test_output,
            )
        except RuntimeError as error:
            self.logger.error(
                "Could not process agent verification result: %s",
                error,
            )
            self._set_agent_status("Verifikation konnte nicht verarbeitet werden")
            return

        if state == AgentState.COMPLETED:
            self._set_agent_status("Tests bestanden")
        elif state == AgentState.ANALYZING:
            self._set_agent_status("Tests fehlgeschlagen, Analyse erforderlich")
            self._start_agent_recovery(test_output)

        self.logger.info(
            "Agent verification finished: success=%s, exit_code=%s, state=%s",
            success,
            exit_code,
            state.value,
        )

    def _start_agent_recovery(self, test_output: str) -> None:
        """Startet Analyse und Reparatur nach einem fehlgeschlagenen Testlauf."""
        if self._agent_orchestrator is None:
            return
        if self._agent_task is None:
            self._set_agent_status("Recovery nicht möglich: keine Agent-Aufgabe")
            return
        if self._agent_recovery_worker is not None:
            return
        project = self.workspace.active_project
        if not project:
            self._set_agent_status("Kein Projekt für Recovery")
            return

        # Never hand the pre-execution snapshot to recovery after a failed
        # refresh. Read grants and the existing context budget still apply.
        self._agent_project_context = ""
        try:
            self.workspace.refresh_index()
            if self._agent_reality is not None:
                RealityCollector(self.workspace.analyzer).collect_project(
                    self._agent_reality,
                    project,
                )
            self._agent_project_context = self._build_agent_project_context(
                refresh_budget=False,
            )
        except Exception as error:
            self._agent_orchestrator.fail()
            self.input_bar.set_busy(False)
            self.logger.error("Recovery context refresh failed: %s", error)
            self._set_agent_status("Recovery gestoppt: Projektkontext konnte nicht aktualisiert werden")
            return

        self._set_agent_status("analysiere fehlgeschlagenen Testlauf")
        self.input_bar.set_busy(True)

        worker = AgentRecoveryWorker(
            orchestrator=self._agent_orchestrator,
            task=self._agent_task,
            test_output=test_output,
            project_context=self._agent_project_context,
            model=self.model,
            base_url=self.ollama_url,
            review_enabled=self.agent_review_enabled,
            num_ctx=self._agent_num_ctx,
            parent=self,
        )
        self._agent_recovery_worker = worker
        worker.completed.connect(self._agent_recovery_finished)
        worker.failed.connect(self._agent_recovery_failed)
        worker.start()

    def _agent_recovery_finished(
        self,
        orchestrator: AgentOrchestrator,
        analysis,
        plan,
    ) -> None:
        worker = self._agent_recovery_worker
        self._agent_recovery_worker = None

        if worker is not None:
            worker.deleteLater()

        self._agent_orchestrator = orchestrator
        self._agent_plan = plan
        self.input_bar.set_busy(False)

        self._request_agent_plan_approval(
            plan,
            dialog_title="Reparaturplan freigeben",
            dialog_intro=(
                "Der Agent hat den fehlgeschlagenen Test analysiert und "
                "einen Reparaturplan erstellt."
            ),
        )

    def _agent_recovery_failed(self, error: str) -> None:
        worker = self._agent_recovery_worker
        self._agent_recovery_worker = None

        if worker is not None:
            worker.deleteLater()

        self.input_bar.set_busy(False)
        self._set_agent_status("Recovery-Fehler")
        self.logger.error("Agent recovery worker failed: %s", error)

    def _request_agent_plan_approval(
        self,
        plan,
        *,
        dialog_title: str,
        dialog_intro: str,
    ) -> None:
        if not plan.proposed_changes:
            if self._agent_orchestrator is not None:
                try:
                    self._agent_orchestrator.complete_without_changes()
                except RuntimeError as error:
                    self.logger.error(
                        "Could not complete no-op agent plan: %s",
                        error,
                    )
                    self._set_agent_status(
                        "Agentenlauf konnte nicht abgeschlossen werden"
                    )
                    return

            self.input_bar.set_busy(False)
            self._set_agent_status("Keine änderungen erforderlich")

            if self.chat_view.pending:
                self.chat_view.pending.set_content(
                    "### Agent-Plan\n\n"
                    f"**Zusammenfassung:** {plan.summary}\n\n"
                    "**Geplante änderungen:**\n"
                    "- Keine konkreten änderungen\n\n"
                    f"**Begründung:** {plan.rationale}\n\n"
                    "*Keine Dateiänderung erforderlich.*"
                )

            return

        changes = []
        for change in plan.proposed_changes:
            action = change.get("action", "unbekannt")
            path = change.get("path", "")
            description = change.get("description", "")
            changes.append(
                f"- {action} {path}: {description}"
            )

        plan_message = (
            f"### Agent-Plan\n\n"
            f"**Zusammenfassung:** {plan.summary}\n\n"
            f"**Geplante änderungen:**\n"
            + (
                "\n".join(changes)
                if changes
                else "- Keine konkreten änderungen"
            )
            + f"\n\n**Begründung:** {plan.rationale}"
        )

        self._set_agent_status("Freigabe erforderlich")
        self.input_bar.set_busy(False)

        if self.chat_view.pending:
            self.chat_view.pending.set_content(plan_message)

        if self.chat_id is not None:
            self.history.add_message(
                self.chat_id,
                "assistant",
                plan_message,
            )

        answer = QMessageBox.question(
            self,
            dialog_title,
            (
                f"{dialog_intro}\n\n"
                f"{plan.summary}\n\n"
                "Sollen die geplanten änderungen ausgeführt werden?"
            ),
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
            QMessageBox.StandardButton.Yes,
        )

        if answer != QMessageBox.StandardButton.Yes:
            if self._agent_orchestrator is not None:
                self._agent_orchestrator.abort()
            self._set_agent_status("abgebrochen")
            return

        if self._agent_orchestrator is None:
            self._set_agent_status("Kein Agentenlauf vorhanden")
            return

        self._agent_orchestrator.approve()
        self._set_agent_status("führe Plan aus")
        self._start_agent_coder_stream()

    def _agent_verification_failed(self, error: str) -> None:
        worker = self._agent_verification_worker
        self._agent_verification_worker = None

        if worker is not None:
            worker.deleteLater()

        orchestrator = self._agent_orchestrator
        if orchestrator is not None and orchestrator.run.state == AgentState.TESTING:
            try:
                state = orchestrator.handle_verification_result(
                    False,
                    f"Verification worker error: {error}",
                )

                if state == AgentState.ANALYZING:
                    self._set_agent_status(
                        "Verifikationsfehler, Analyse erforderlich"
                    )
                    self._start_agent_recovery(
                        f"Verification worker error: {error}"
                    )
                    return

            except RuntimeError as processing_error:
                self.logger.error(
                    "Could not process verification worker failure: %s",
                    processing_error,
                )

        self._set_agent_status("Verifikationsfehler")
        self.logger.error(
            "Agent verification worker failed: %s",
            error,
        )

    @classmethod
    def _is_ai_control_file(cls, path: Path) -> bool:
        source_root = Path(__file__).resolve().parents[2]
        return path.resolve() in {source_root / relative for relative in cls.AI_CONTROL_FILES}

    def _response_failed(self, error: str) -> None:
        self.logger.error("Ollama request failed: %s", error)
        if self.chat_view.pending:
            self.chat_view.pending.set_content(f"**Fehler:** {error}\n\nStarte Ollama und prüfe die Einstellungen.")
        self.input_bar.set_busy(False)

    def choose_project(self) -> None:
        folder = QFileDialog.getExistingDirectory(
            self,
            "Projekt auswählen",
            "",
            QFileDialog.Option.DontUseNativeDialog,
        )
        if folder:
            self.open_project(folder)

    def open_project(self, path: str) -> None:
        try:
            statistics = self.workspace.open_project(path)
        except ValueError as error:
            self.logger.warning("Project could not be opened: %s", error)
            QMessageBox.warning(self, "Projekt öffnen", str(error))
            return
        if self.workspace.ai_grants() and self.workspace.project_mode() == ProjectMode.READ_ONLY:
            self.workspace.set_project_mode(ProjectMode.WRITE_WITH_CONFIRMATION)
        self.project_panel.set_project(path)
        self.terminal.set_working_directory(path)
        self._update_status(statistics.file_count, "indexiert")

    def close_project(self) -> None:
        self.workspace.close_project()
        self.project_panel.project_name.setText("Kein Projekt geöffnet")
        self._update_status()

    def refresh_index(self) -> None:
        statistics = self.workspace.refresh_index()
        if statistics:
            self._update_status(statistics.file_count, "indexiert")

    def analyze_project(self) -> None:
        analysis = self.workspace.analyze_project()
        if not analysis:
            QMessageBox.information(self, "Projekt analysieren", "Bitte öffne zuerst ein Projekt.")
            return
        self._update_status(len(analysis["files"]), "analysiert")
        message = (
            f"{analysis['project_name']}: {len(analysis['files'])} Dateien, "
            f"{len(analysis['modules'])} Python-Module, "
            f"{sum(len(items) for items in analysis['classes'].values())} Klassen"
        )
        if analysis["is_self_project"]:
            message += "\nForgeAI analysiert gerade seinen eigenen Quellcode."
        QMessageBox.information(self, "Projektanalyse", message)

    def analyze_project_with_ollama(self) -> None:
        if not self.workspace.active_project:
            QMessageBox.information(self, "Ollama Projektanalyse", "Kein Projekt geöffnet.")
            return
        analysis = self.workspace.analyze_with_ollama(Config.LOCAL_OLLAMA_URL)
        if not analysis:
            QMessageBox.information(self, "Ollama Projektanalyse", "Analyse fehlgeschlagen.")
            return
        self._update_status(len(analysis["files"]), "analysiert mit Ollama")
        message = (
            f"{analysis['project_name']}: {len(analysis['files'])} Dateien, "
            f"{len(analysis['modules'])} Python-Module, "
            f"{sum(len(items) for items in analysis['classes'].values())} Klassen"
        )
        if analysis["is_self_project"]:
            message += "\nForgeAI analysiert gerade seinen eigenen Quellcode."
        QMessageBox.information(self, "Ollama Projektanalyse", message)

    def show_project_information(self) -> None:
        if not self.workspace.active_project:
            QMessageBox.information(self, "Projektinformationen", "Kein Projekt geöffnet.")
            return
        analysis = self.workspace.brain.load_analysis(self.workspace.active_project)
        if not analysis:
            QMessageBox.information(self, "Projektinformationen", "Noch keine Analyse vorhanden.")
            return
        QMessageBox.information(
            self, "Projektinformationen",
            f"Name: {analysis['project_name']}\nDateien: {len(analysis['files'])}\n"
            f"Ordner: {len(analysis['folders'])}\nSprachen: {', '.join(analysis['languages'])}\n"
            f"Git: {'ja' if analysis['git_repository'] else 'nein'}\n"
            f"Selbstanalyse: {'ja' if analysis['is_self_project'] else 'nein'}",
        )

    def open_file(self, path: str) -> None:
        self.file_viewer.open_file(path)
        if self.workspace.active_project:
            self.database.execute("UPDATE project_state SET last_opened_file=? WHERE project_path=?", (path, str(self.workspace.active_project)))

    def grant_ai_access(self, path: str) -> None:
        target_name = self.workspace.filesystem.resolve(path).name
        answer = QMessageBox.question(
            self, "KI-Freigabe", 
            f"{target_name} für die lokale KI freigeben? Der Inhalt wird nur an Ollama auf diesem Computer übergeben.",
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
            QMessageBox.StandardButton.No,
        )
        if answer == QMessageBox.StandardButton.Yes:
            self.workspace.grant_ai_access(path)
            if self.workspace.project_mode() == ProjectMode.READ_ONLY:
                self.workspace.set_project_mode(ProjectMode.WRITE_WITH_CONFIRMATION)
            self._update_status()

    def revoke_ai_access(self, path: str) -> None:
        self.workspace.revoke_ai_access(path)
        self._update_status()

    def grant_ai_access_many(self, paths: list[str]) -> None:
        answer = QMessageBox.question(
            self, "KI-Freigabe",
            f"{len(paths)} Dateien für die lokale KI freigeben? Die Inhalte werden nur an Ollama auf diesem Computer übergeben.",
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
            QMessageBox.StandardButton.No,
        )
        if answer == QMessageBox.StandardButton.Yes:
            for path in paths:
                self.workspace.grant_ai_access(path)
            if self.workspace.project_mode() == ProjectMode.READ_ONLY:
                self.workspace.set_project_mode(ProjectMode.WRITE_WITH_CONFIRMATION)
            self._update_status()

    def revoke_ai_access_many(self, paths: list[str]) -> None:
        for path in paths:
            self.workspace.revoke_ai_access(path)
        self._update_status()

    def populate_recent_projects(self) -> None:
        self.recent_menu.clear()
        for project in self.workspace.recent_projects():
            self.recent_menu.addAction(project["name"], lambda checked=False, path=project["path"]: self.open_project(path))

    def toggle_favorite(self) -> None:
        if not self.workspace.active_project:
            return
        row = self.database.fetchone("SELECT is_favorite FROM project_state WHERE project_path=?", (str(self.workspace.active_project),))
        self.workspace.set_favorite(not bool(row["is_favorite"]))

    def focus_terminal(self) -> None:
        self.terminal.command.setFocus()

    def show_tasks(self) -> None:
        if self.workspace.active_project:
            TasksDialog(self.tasks, self.workspace.active_project, self).exec()

    def show_logs(self) -> None:
        self.file_viewer.open_file(Config.LOG_PATH)

    def show_system_prompt(self) -> None:
        QMessageBox.information(self, "Systemprompt", SYSTEM_PROMPT)

    def show_context(self) -> None:
        project = self.workspace.active_project
        text = f"Projekt: {project or 'keines'}\nModus: {self.workspace.project_mode().value}\nModell: {self.model}"
        QMessageBox.information(self, "Kontext", text)

    def _update_status(self, file_count: int = 0, index_state: str = "bereit") -> None:
        project = self.workspace.active_project
        self.workspace_status.setText("Workspace: lokal")
        grant_count = len(self.workspace.ai_grants())
        self.workspace_status.setText(f"Workspace: lokal | KI-Freigaben: {grant_count}")
        self.index_status.setText(f"Index: {index_state}")
        self.backend_status.setText("Backend: Ollama lokal")
        self.project_status.setText(f"Projekt: {project.name if project else 'keines'}")
        self.model_status.setText(f"Modell: {self.model}")
        self.ollama_status.setText(f"Ollama: {self.ollama_url}")
        git_available = project and self.workspace.filesystem.is_directory(project / ".git")
        self.git_status.setText(f"Git: {'Projekt' if git_available else '–'}")
        self.file_status.setText(f"Dateien: {file_count}")

    def show_settings(self) -> None:
        settings = {row["key"]: row["value"] for row in self.database.fetchall("SELECT key, value FROM settings")}
        if self.workspace.active_project:
            settings["project_mode"] = self.workspace.project_mode().value
        dialog = SettingsDialog(self.ollama_url, self.model, settings, self)
        if dialog.exec():
            values = dialog.values()
            self.ollama_url, self.model = Config.LOCAL_OLLAMA_URL, values["model"]
            for key, value in values.items():
                self._save_setting(key, value)
            if self.workspace.active_project:
                self.workspace.set_project_mode(ProjectMode(values["project_mode"]))
            self._apply_theme()
            self._update_status()
